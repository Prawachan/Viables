Viables
Empowers students to build a sustainable tomorrow.

Project for BrickHack 6

Creative Goals
Why:
Campus students are not actively engaged in reducing garbage and waste, which they receive in form cartons while shopping online. 
College campuses are often communities that can engage in reducing their carbon footprint by incentivizing their students to inculcate sustainability in their daily routines.
Global warming is constantly affecting our lives in America. Last year was the hottest year on record and while the problem might seem to be that of politicians and policymakers to make decisions to reduce emissions and build sustainable economies, living sustainable lives now is a part we can all play as college students. We take on the challenge of reusing, by building a platform where students can exchange carton boxes that were used for packaging for credit in the form of campus cash or dining dollars. This kind of gamification of the process of reusing will encourage students to be more actively engaged in acting to reduce the amount of waste they generate. 


Target Users
Students

Solution
This platform is meant for college students, which provide the students with a list of supported colleges, along with their drop-off centers which later on can be used by students to make it easier to drop-off used cartons, which they get while shopping online. These centers can be any UPS drop-off centers or a dedicated center for hauling their cartons to those centers.

Students select their schools from a list of schools provided. 
This prompts the student to select a center near them within their school.
Furthermore, they need to enter the number of cartons. Numbers of the cartons decide the points to be credited in the student’s account.
Based on this, a QR code is generated that helps the student to scan that to the drop-off center to get the credit points.
When points are credited, students might use them on getting used books that are donated by other students.


Specifications:
Website
Technologies: 
HTML
CSS
Javascript


Team CLEAP 
Esha Shandilya - First-Year Graduate, Human-Computer Interaction; 
     Idea Generation; Concept and UI Design.
Colin Zee - Freshman, Systems Design Engineering
Laurence - Senior, Computer Science (major), Creative Writing (minor)
Prawachan Dhungana - Second Year UnderGraduate, Computer Information Systems -           
